import React, {Component} from 'react';
import InputNumber from './InputNumber';

class LotteryGame extends Component {
    state = {
        inputValue: '',
        inputList: [],
        resultString: ''
    }

    componentDidMount() {

    }

    componentDidUpdate() {

    }

    componentWillUnmount() {

    }

    onSubmitForm = (input) => {
        const {inputValue, inputList} = this.state;

        this.setState((prevState) => {
            return {
                inputList: [...prevState.inputList, inputValue],
                inputValue: ''
            };
        });
    };

    onChangeValue = (e) => {
        this.setState({inputValue: e.target.value});
    }

    render() {
        const {inputValue, inputList, resultString} = this.state;

        return (
            <>
                <div>7개의 숫자를 입력해주세요. (1 ~ 45사이의 값을 입력해주세요)</div>
                <form onSubmit={this.onSubmitForm}>
                    <input type='number' value={inputValue} onChange={this.onChangeValue}/>
                </form>
                <div>{inputList}</div>
            </>
        );
    }
}

export default LotteryGame;